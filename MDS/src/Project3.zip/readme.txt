This file contains MDS algorithm. It was written and compiled in Intellij IDE.
